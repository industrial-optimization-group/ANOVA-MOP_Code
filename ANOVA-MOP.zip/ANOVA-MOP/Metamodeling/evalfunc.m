function evalfunc=evalfunc(x)

evalfunc=TestFunctions(x,1);
